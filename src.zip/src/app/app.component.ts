import { Component, ViewChild } from '@angular/core';
import { Nav, Platform,ModalController  } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
//import {LoginPage} from '../pages/login/login';
//import {SignupPage} from '../pages/signup/signup';
import {MenuPage} from '../pages/menu/menu';
import {NonvegDetailPage} from '../pages/nonveg-detail/nonveg-detail';
import { firebaseConfig } from './credentials';
//import { GeoMap} from '../pages/geo-map/geo-map';
//import {GoogleMap} from '../pages/g-map/g-map';
import { SplashPage } from '../pages/splash/splash';
import firebase from 'firebase';
@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = HomePage;

  pages: Array<{title: string, component: any}>;

  constructor(public platform: Platform, public statusBar: StatusBar, splashScreen: SplashScreen, modalCtrl: ModalController) {
   // this.initializeApp();
    firebase.initializeApp(firebaseConfig);
    // used for an example of ngFor and navigation
    this.pages = [
        { title: 'Home', component: HomePage },
      //  { title: 'Login', component: 'LoginPage'},
      //  { title: 'Signup', component: 'SignupPage'},
        { title: 'Location selection', component: 'LocationSelectionPage' },
        { title: 'AboutUs', component: 'AboutUsPage' },
        { title:'Order History',component:'OrderHistoryPage'},
     //   { title: 'Privacy Policy', component: 'PrivacyPolicyPage' },
     //   { title: 'Content Policy', component: 'ContentPolicyPage' },
     //   { title: 'Cookie Policy', component: 'CookiePolicyPage' },
      //  { title: 'Feedback', component: 'FeedbackPage' },
      //  { title: 'Menu list', component: 'MenulistPage' },
      //  {title:'Order Detail', component:'OrderDetailPage'},
        { title: 'Profile', component: 'ProfilePage' },
      // { title: 'Restaurant', component: 'RestaurantPage' },
        { title: 'Restaurant List', component: 'RestaurantListPage' },
        { title: 'Search', component: 'SearchPage' },
        
     //   { title: 'Terms of service', component: 'TermsOfServicePage' },
		  //  { title:'Geo Map', component:'GeoMap'},
      //  {title:'Google Map',component:'GoogleMap'}
    ];
    
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      //this.splashScreen.hide();
      statusBar.styleDefault();
 
            let splash = modalCtrl.create(SplashPage);
            splash.present();
    });
     
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }
}
