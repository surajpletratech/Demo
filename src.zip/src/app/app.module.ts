import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ElasticHeaderModule } from 'ionic2-elastic-Header/dist';
import { HideHeaderDirective } from '../directives/hide-header/hide-header';
import {AuthProvider} from '../providers/auth/auth';
import { Ionic2RatingModule } from 'ionic2-rating';
import { Geolocation } from '@ionic-native/geolocation';
import { HttpModule } from '@angular/http';
import { SplashPage } from '../pages/splash/splash';
import {BarRatingModule} from 'ngx-bar-rating'
@NgModule({ 
  declarations: [
    MyApp,
    HomePage,
    
    HideHeaderDirective,
    SplashPage
  
  
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    ElasticHeaderModule,
   // Ionic2RatingModule,
    HttpModule,
    //BrowserAnimationsModule,
    BarRatingModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    SplashPage  
  
  ],
  providers:[
    Geolocation,
    SplashScreen,
    {provide:ErrorHandler,useClass:IonicErrorHandler},
    AuthProvider,
    StatusBar
  ]
 
})
export class AppModule {}
