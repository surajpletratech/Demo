export const firebaseConfig = {
    apiKey: "AIzaSyBHMEjesXY-7MnZjAxA1wUj76ZD_vQh0CA",
    authDomain: "training-9f4c4.firebaseapp.com",
    databaseURL: "https://training-9f4c4.firebaseio.com",
    projectId: "training-9f4c4",
    storageBucket: "training-9f4c4.appspot.com",
    messagingSenderId: "158338915819"}
