import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import firebase from 'firebase';
/*
  Generated class for the AuthProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class AuthProvider {

  constructor() {
    
  }

  loginUser(email: string, password: string): Promise<any> {
      return firebase.auth().signInWithEmailAndPassword(email, password);
  }

  signupUser(email: string,
      password: string,
      name: string,
      pmobile: string): Promise<any> {
      return firebase
          .auth()
          .createUserWithEmailAndPassword(email, password)
          .then(newUser => {
              firebase.database().ref(`/userProfile/${newUser.uid}`)
                  .set({
                      name: name,
                      email: email,
                      mobileNumber: pmobile
                  });
          })
          .catch(error => {
              console.error(error);
              throw new Error(error);
          });
  }

  resetPassword(email: string): Promise<any> {
      return firebase.auth().sendPasswordResetEmail(email).then(function () {
          // Email sent.
          return true;
      }).catch(function (error) {
          // An error happened.
          throw new Error(error);
      });
  }

  logoutUser(): Promise<void> {
      const userId: string = firebase.auth().currentUser.uid;
      firebase.database().ref(`/userProfile/${userId}`).off();
      return firebase.auth().signOut();
  }
}
