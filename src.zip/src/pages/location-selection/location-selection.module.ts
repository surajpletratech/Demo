import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LocationSelectionPage } from './location-selection';

@NgModule({
  declarations: [
    LocationSelectionPage,
  ],
  imports: [
    IonicPageModule.forChild(LocationSelectionPage),
  ],
})
export class LocationSelectionPageModule {}
