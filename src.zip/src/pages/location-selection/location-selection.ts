import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import {  ViewChild, ElementRef } from '@angular/core';
/**
 * Generated class for the LocationSelectionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
declare var google: any;
@IonicPage()

@Component({
  selector: 'page-location-selection',
  templateUrl: 'location-selection.html',
})
export class LocationSelectionPage {
  /* lat: any;
  lng: any; */
  @ViewChild('map') mapRef: ElementRef;
  map : any;
  google: any;
  positionOption ={ timeout:10000, enableHighAccuracy:false};
  constructor(public navCtrl: NavController, public navParams: NavParams,private geolocation: Geolocation) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LocationSelectionPage');
    console.log(this.mapRef);
    this.showMap();
  }

/*   getLoc(){
    this.geolocation.getCurrentPosition(this.positionOption).then( pos =>{
    this.lat = pos.coords.latitude;
    this
      alert(this.lat);
    this.lng = pos.coords.longitude;
      alert(this.lng);
  }).catch( err => console.log(err));
} */

showMap(){
  //Location - lat lng
  const location = new google.maps.LatLng(18.461077,73.925133);

  //Map options
  const options = {
    center: location,
    zoom: 10
  }
  
this.map = new google.maps.Map(this.mapRef.nativeElement,options);
this.addMarker(location, this.map);
}

addMarker(position, map){
  return new google.maps.Marker({
    position,
    map
  });
}

}
