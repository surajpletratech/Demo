import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';

@Component({
  selector: 'page-geo-map',
  templateUrl: 'geo-map.html'
})
export class GeoMap {
  
  lat: any;
  lng: any;
  constructor(public navCtrl: NavController, private geolocation: Geolocation) {  }

   getLoc(){
      this.geolocation.getCurrentPosition().then( pos =>{
      this.lat = pos.coords.latitude;
        alert(this.lat);
      this.lng = pos.coords.longitude;
        alert(this.lng);
    }).catch( err => console.log(err));
  }

}
