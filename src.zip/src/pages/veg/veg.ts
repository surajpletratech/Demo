import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {ViewCartPage} from '../view-cart/view-cart';
/**
 * Generated class for the VegPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-veg',
  templateUrl: 'veg.html',
})
export class VegPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad VegPage');
  }
  viewCart():void{
    this.navCtrl.push('ViewCartPage');
  }
}
