import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OrderHistoryPage } from './order-history';
import {BarRatingModule} from 'ngx-bar-rating'
@NgModule({
  declarations: [
    OrderHistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(OrderHistoryPage),
    BarRatingModule
  ],
})
export class OrderHistoryPageModule {}
