import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NewPoonabakeryPage } from './new-poonabakery';

@NgModule({
  declarations: [
    NewPoonabakeryPage,
  ],
  imports: [
    IonicPageModule.forChild(NewPoonabakeryPage),
  ],
})
export class NewPoonabakeryPageModule {}
