import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddreviewPage } from './addreview';
import {BarRatingModule} from 'ngx-bar-rating'
@NgModule({
  declarations: [
    AddreviewPage,
  ],
  imports: [
    IonicPageModule.forChild(AddreviewPage),
    BarRatingModule
  ],
})
export class AddreviewPageModule {}
