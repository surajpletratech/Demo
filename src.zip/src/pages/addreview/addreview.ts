import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import{ AlertController} from 'ionic-angular';
import {BarRatingModule} from 'ngx-bar-rating';
/**
 * Generated class for the AddreviewPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addreview',
  templateUrl: 'addreview.html',
})
export class AddreviewPage {
  review:FormGroup;
  starRating = 3;
  vRating = 1;
  faoRating = 5.6;
  movieRating = 2;

  public addReview:string;
  constructor(public navCtrl: NavController, public navParams: NavParams, public alertCtrl: AlertController,public formBuilder:FormBuilder) {
      this.review=formBuilder.group({
        addReview: ['review',Validators.required]
      })
  }

  Rating(){
    const alert = this.alertCtrl.create({
      title: 'Rate Restaurant:',
      //subTitle: '',
      cssClass: 'alertstar',
      enableBackdropDismiss:false,
      buttons: [
           { text: '1',cssClass: 'alertstar'}, 
           { text: '2',cssClass: 'alertstar'}, 
           { text: '3',cssClass: 'alertstar'}, 
           { text: '4',cssClass: 'alertstar'}, 
           { text: '5',cssClass: 'alertstar'}, 
      ]
 });
 alert.present();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddreviewPage');
  }

}
