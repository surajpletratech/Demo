import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {MenuPage} from '../menu/menu';
import {VegPage} from '../veg/veg';
import {Food} from '../../interface/foodlist/foodlist';
 /**
 * Generated class for the MenulistPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-menulist',
  templateUrl: 'menulist.html',
})
export class MenulistPage {
  food:Food =null;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
     this.food = this.getFoodlist(); 
 }

 gotoMenuList(){
    console.log('menulist');
    this.navCtrl.push('MenuPage');
  }

  gotoVegMenu(){
    this.navCtrl.push('VegPage');
  }

  gotoMithaiMenu(){
    this.navCtrl.push('MithaiPage');
  }

  gotoMenu(){
      this.navCtrl.push('NonvegDetailPage');
  }
  gotoChineseMenu(){
    this.navCtrl.push('ChineseFoodPage');
  }
  
  gotoCartPage(){
    this.navCtrl.push('CartPage');
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad MenulistPage');
  }
   
  getFoodlist():Food{
    let foodies:Food ={
      name:'Chicken Lolipop',
      description:'The oriental chicken lollipops get a desi makeover.A great party starter!',
      cost:500,
    };
       return foodies;
  } 

}
