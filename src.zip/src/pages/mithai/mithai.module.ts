import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MithaiPage } from './mithai';

@NgModule({
  declarations: [
    MithaiPage,
  ],
  imports: [
    IonicPageModule.forChild(MithaiPage),
  ],
})
export class MithaiPageModule {}
