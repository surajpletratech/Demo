import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhoneverficationPage } from './phoneverfication';

@NgModule({
  declarations: [
    PhoneverficationPage,
  ],
  imports: [
    IonicPageModule.forChild(PhoneverficationPage),
  ],
})
export class PhoneverficationPageModule {}
