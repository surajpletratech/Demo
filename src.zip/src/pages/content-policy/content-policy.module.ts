import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ContentPolicyPage } from './content-policy';

@NgModule({
  declarations: [
    ContentPolicyPage,
  ],
  imports: [
    IonicPageModule.forChild(ContentPolicyPage),
  ],
})
export class ContentPolicyPageModule {}
