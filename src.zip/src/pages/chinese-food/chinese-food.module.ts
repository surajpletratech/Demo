import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChineseFoodPage } from './chinese-food';

@NgModule({
  declarations: [
    ChineseFoodPage,
  ],
  imports: [
    IonicPageModule.forChild(ChineseFoodPage),
  ],
})
export class ChineseFoodPageModule {}
