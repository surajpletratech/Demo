import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {FormGroup,FormBuilder,Validators} from '@angular/forms';
//import { Validators } from '@angular/forms/src/validators';
/**
 * Generated class for the TextBoxPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-text-box',
  templateUrl: 'text-box.html',
})
export class TextBoxPage {
  profile:FormGroup;
  public Email:string;
  public mobile:string;
  public name:string
  public password:string 
  constructor(public navCtrl: NavController, public navParams: NavParams,public formbuilder:FormBuilder) {
      this.profile = formbuilder.group({
        UserName:['FoodMania',Validators.required],
        Email:['foodMania',Validators.required],
        Password:['***',Validators.required]
      })
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad TextBoxPage');
  }

  over(){
    console.log('In Mouse Event');
  }
}
