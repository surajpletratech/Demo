import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TextBoxPage } from './text-box';

@NgModule({
  declarations: [
    TextBoxPage,
  ],
  imports: [
    IonicPageModule.forChild(TextBoxPage),
  ],
})
export class TextBoxPageModule {}
