import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

/**
 * Generated class for the AddressDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-address-detail',
  templateUrl: 'address-detail.html',
})
export class AddressDetailPage {
  slideOneForm: FormGroup;
   
   public Address:string;
   public mobileNo:string;
   constructor(public navCtrl: NavController, public navParams: NavParams, public formBuilder:FormBuilder) {
    
    this.slideOneForm = formBuilder.group({
      Address:['03 abc building'],
  
    }); 
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddressDetailPage');
  }
  gotoPayment()
  {
    this.navCtrl.push("ViewCartPage");
  }
  gotoConfirmationpagePage(){
    this.navCtrl.push('ConfirmationpagePage');
  }

  gotoMobileDetail(){
    this.navCtrl.push('MobileDetailPage');
  }
}
