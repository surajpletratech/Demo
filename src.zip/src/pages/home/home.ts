import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
//import {SignupPage} from '../signup/signup';
import {LoginPage} from '../login/login';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {

  }

  SignUp(): void {
      this.navCtrl.push('SignupPage');
  }

  LogIn(): void {
      this.navCtrl.push('LoginPage');
  }

  ContinueWithoutLogin(): void {
      this.navCtrl.push('LocationSelectionPage');
  }

}