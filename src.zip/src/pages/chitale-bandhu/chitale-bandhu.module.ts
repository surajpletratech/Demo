import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChitaleBandhuPage } from './chitale-bandhu';

@NgModule({
  declarations: [
    ChitaleBandhuPage,
  ],
  imports: [
    IonicPageModule.forChild(ChitaleBandhuPage),
  ],
})
export class ChitaleBandhuPageModule {}
