import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {AllReviewPage} from '../all-review/all-review';
import {AddreviewPage} from '../addreview/addreview';
import {MenuDetailPage} from '../menu-detail/menu-detail';
/**
 * Generated class for the ChitaleBandhuPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-chitale-bandhu',
  templateUrl: 'chitale-bandhu.html',
})
export class ChitaleBandhuPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  showAllReview(){
    this.navCtrl.push('AllReviewPage');
  }
  addReview(){
    this.navCtrl.push('AddreviewPage');
  }

  gotoMenu(){
    this.navCtrl.push('MenuDetailPage');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChitaleBandhuPage');
  }

}
