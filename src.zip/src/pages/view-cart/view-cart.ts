import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {PaymentPage} from '../payment/payment';
/**
 * Generated class for the ViewCartPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-view-cart',
  templateUrl: 'view-cart.html',
})
export class ViewCartPage {
  isChecked = false;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ViewCartPage');
  }

  gotoPayment(){
     this.navCtrl.push('PaymentPage');
  }
  myFunction($event){
    this.isChecked= !this.isChecked; // I am assuming you want to switch between checking and unchecking while clicking on radio.
  }
  gotoCard(){
    console.log('in card');
    this.navCtrl.push('CardDetailPage');
  }

  gotoWallet(){
    this.navCtrl.push('WalletPage');
  }
  BankListPage(){
    this.navCtrl.push('BankListPage');
    
  }
}
