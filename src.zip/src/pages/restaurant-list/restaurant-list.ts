import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {NewPoonabakeryPage} from '../new-poonabakery/new-poonabakery';
import {ChitaleBandhuPage} from '../chitale-bandhu/chitale-bandhu';
//import { restaurant } from '../interface/restaurant';
//import { restaurant } from '../interface/restaurant/restaurant';
import{ Restaurant } from '../../interface/restaurant/restaurant';

/**
 * 
 * Generated class for the RestaurantListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-restaurant-list',
  templateUrl: 'restaurant-list.html',
})
export class RestaurantListPage {
  restaurant:Restaurant=null;

 //public restaurant_name:string='New Poona Bakery';
 //public location:string;
 //public restaurant_type:string;
 //public rating:number=null;
   constructor(public navCtrl: NavController, public navParams: NavParams) {
     this.restaurant = this.getRestaurant();
     //this.rating=4.2;
     //this.location="Hadapsar,pune,Maharashtra";
     //this.restaurant_type="South Indian,Thali, Chiken Special";
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RestaurantListPage');
  }

  newPoona(){
    this.navCtrl.push('NewPoonabakeryPage');
  }

  chitlebandhu(){
      this.navCtrl.push('ChitaleBandhuPage');
  }
         
  gotoMenu(){
    this.navCtrl.push('MenulistPage');
  }

  addResturant(){
    this.navCtrl.push('addRestaurantPage')
  }

  getRestaurant(): Restaurant {
      let restau: Restaurant = {
        name: 'Onesta',
        location: 'Hadapsar,Pune,Maharashtra',
        minPrice:300,
        rating: 4.2,
        city:'Hadapsar,Pune,Maharashtra',
        state:'maharashtra',
        country:'India',
        type:'North Indian,Non Veg',
        contact:8149556,    
      };
      return restau;
    }

    /*over(){
      console.log("mouse event");
    }*/
  }
  
