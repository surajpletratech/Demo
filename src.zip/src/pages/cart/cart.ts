import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {Cart} from '../../interface/cart/cart';
/**
 * Generated class for the CartPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cart',
  templateUrl: 'cart.html',
})
export class CartPage {
   public currentNumber:number=1;
   public total:number=null;
   cart : Cart = null; 
   buttonDisabled:boolean;
   constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.cart = this.getAllCartItem();
  }
  
  increment(){
   /* this.cart.item_count;
    this.cart.item_count++;*/
    this.currentNumber++;
    this.total = this.currentNumber * 250;
    
  }
  decrement(){
    /*this.cart.item_count;
    this.cart.item_count--;*/
    this.currentNumber--;
    this.total = this.total - 250;
    if(this.currentNumber <= 0)
    {
      this.total=0;
      
    }
    if(this.currentNumber>0)
    {
      this.buttonDisabled= false;
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CartPage');
  }
  AddressPage(){
    this.navCtrl.push('AddressDetailPage');
  }

  getAllCartItem():Cart{
    let cartitem:Cart ={
      item_count : 0,
      //item-count: null;
      item_name : 'Chicken Lolipop',
      total:0 ,
      Grandtotal :0 ,
      tax:40
    };
    return cartitem;
  }

}
