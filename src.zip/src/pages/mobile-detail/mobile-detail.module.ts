import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MobileDetailPage } from './mobile-detail';

@NgModule({
  declarations: [
    MobileDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(MobileDetailPage),
  ],
})
export class MobileDetailPageModule {}
