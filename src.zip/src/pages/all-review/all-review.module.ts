import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AllReviewPage } from './all-review';

@NgModule({
  declarations: [
    AllReviewPage,
  ],
  imports: [
    IonicPageModule.forChild(AllReviewPage),
  ],
})
export class AllReviewPageModule {}
