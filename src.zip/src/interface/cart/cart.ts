export interface Cart
{
    item_count:number;
    item_name:string;
    total:number;
    Grandtotal:number;
    tax:number;
}