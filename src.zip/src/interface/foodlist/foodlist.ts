export interface Food {
    name: string;
    description: string;
    cost: number;   
}   