import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import {DataService} from '../../app/data-service.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DialogComponent } from '../dialog/dialog.component';

@Component({ 
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {
  public name='Email has been sent';
  public title="Reset Link";
  public resetPasswordForm: FormGroup;
  emailCtrl: FormControl;
  public myForm: FormGroup;
  constructor(public formBuilder: FormBuilder,public auth:DataService,public dialog: MatDialog) { }

  ngOnInit() {
    this.emailCtrl =  this.formBuilder.control('', [Validators.required,Validators.email]);
    this.myForm = this.formBuilder.group({
      email:this.emailCtrl
    }); 
    
}
OnSubmit(){
  console.log(this.myForm.value.email);
 const email: string = this.myForm.value.email;
this.auth.resetPassword(email).then(function () {
 
    console.log('email has been sent');
}).catch(function (error) {
    console.log('error');
});
let dialogRef = this.dialog.open(DialogComponent, {
  width: '250px',
  height: '250px',
  data:{name:this.name,title:this.title}
});
console.log('hello');
}
}
