export const environment = {
  production: false,
  userCollection:'userprofile',

  firebase: {
    apiKey: "AIzaSyDcY2I_XJT-BaDkE95IfI60w7UPzXzka1A",
    authDomain: "admin-8b2c1.firebaseapp.com",
    databaseURL: "https://admin-8b2c1.firebaseio.com",
    projectId: "admin-8b2c1",
    storageBucket: "admin-8b2c1.appspot.com",
    messagingSenderId: "759351059374"
  }

}
